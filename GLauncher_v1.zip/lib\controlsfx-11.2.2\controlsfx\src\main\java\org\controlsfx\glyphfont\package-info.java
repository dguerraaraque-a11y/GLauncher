/**
 * A package containing a number of useful code related to loading and using
 * font packs whose characters are actually images.
 */
package org.controlsfx.glyphfont;